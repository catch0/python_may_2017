from django.shortcuts import render, redirect
import random

# Create your views here.
def index(request):
    if not 'count' in request.session:
        request.session["count"]=0
    return render(request, 'index.html')
def generate(request):
    letters=["a","b","c","d","e","f","g","h"]
    random_word = ""
    for i in range(14):
        temp = random.randint(0,len(letters)-1)
        random_word += letters[temp]
    request.session["display"] = random_word
    request.session["count"] +=1
    return redirect('/')
def clear(request):
   # if 'random_word' in request.session:
        #request.session.pop('random_word')
    return redirect('/')