from django.shortcuts import render, redirect
from django.contrib import messages
from .models import*
# Create your views here.
def index(request):
    return render(request, 'logapp/index.html')
def valid(request):
    if request.POST:
        #print "inside valid", request.POST
        check=User.objects.isvalid(request.POST)
        print check
        if check['pass']==True:
                user = User.objects.create(first_name=request.POST['first_name'],last_name=request.POST['last_name'],email=request.POST['email'],password=request.POST['password'],confirm_pw=request.POST['confirm_pw'])
            
                context={
                'first_name' : request.POST['first_name'],
                'last_name' : request.POST['last_name'],
                }
                return render(request, 'logapp/valid.html',context)
        context={'errors': check['errors']}
        return render(request, 'logapp/index.html',context)
    else:
        return redirect('/')
def login(request):
    if request.POST:
        logger=User.objects.log(request.POST)
        if logger['pass']==True:
            context={
                'first_name':         User.objects.filter(email=request.POST['email']).first().first_name,
            }
            return render(request, 'logapp/success.html',context)
        else:
            data={
                'errors_login': logger['errors']
            }
            return render(request, 'logapp/index.html', data)
def logout(request):
    if request.POST:
        request.session.clear()
        return redirect('/')
            