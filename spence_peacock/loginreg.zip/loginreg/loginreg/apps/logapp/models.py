from __future__ import unicode_literals
from django.contrib import messages
from django.db import models
from django.contrib import messages
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
NAME_REGEX= re.compile(r'^[a-zA-Z]+$')
class UserManager(models.Manager):
    def isvalid (self, form_data):
        errors =[]
        valid = True
        if len(form_data['first_name'])==0:
            errors.append("please give us your first name, we really need to have it!!")
            valid=False
        if len(form_data['last_name'])==0:
            errors.append("can we please get your last name?")
            valid=False
        if not EMAIL_REGEX.match(form_data['email']):
            errors.append("please enter a valid email")
            valid=False
        if User.objects.filter(email=form_data['email']).first():
            valid=False
            errors.append("awww dude/dudette i think you already registered!!!")
        if len(form_data['password'])<8:
            errors.append("Please use at least 8 charachters")
            valid=False
        if str(form_data['password']) != str(form_data['confirm_pw']):
            errors.append("the password and pw confirm do not match")
            valid=False
        return  {"pass": valid, "errors":errors }
    def log(self, form_data):
        errors=[]
        valid = True
        if User.objects.filter(email=form_data['email']).first()==None:
            errors.append("that email doesn't exist")
            valid = False
        elif User.objects.filter(password=form_data['password']).first()==None:
            errors.append("awww snap, did you forget your password")
            valid=False
        return {"pass": valid, "errors": errors}
class User(models.Model):
    first_name=models.CharField(max_length=255)
    last_name=models.CharField(max_length=255)
    email=models.CharField(max_length=255)
    password=models.CharField(max_length=255)
    confirm_pw=models.CharField(max_length=255)
    objects = UserManager()