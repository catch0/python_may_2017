from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def root():
	return (render_template("index.html"))

@app.route('/don', methods = ['POST'])
def left():
	return (render_template("don.html"))

@app.route('/ralph', methods = ['POST','GET'])
def don():
	return (render_template("ralph.html"))

@app.route('/mike', methods = ['POST'])
def dead1():
	return (render_template("mike.html"))

@app.route('/leo', methods = ['POST'])
def leo():
	return (render_template("leo.html"))
@app.route('/ninja', methods=['POST'])
def ninjas():
    return(render_template("ninja.html"))

app.run(debug = True)