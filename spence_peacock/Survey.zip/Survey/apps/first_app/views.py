from django.shortcuts import render
from django.http import HttpResponseRedirect

# Create your views here.
def index(request):
    return render(request,
    'first_app/index.html')
def result(request):
    context={
        'name': request.POST['name'],
        'location': request.POST['location'],
        'language': request.POST['language'],
        'commments': request.POST['comments']
    }
    return render(request,'first_app/index2.html', context)