from flask import Flask,render_template,request,redirect
app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")
@app.route('/process',methods=['GET'])
def name():
    return redirect('/')
    name=request.form['name']
    print name
    
app.run(debug=True)