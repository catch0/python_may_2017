a = [1, 2, 5, 10, 255, 3]
avg = sum(a)/len(a)
print avg
        
        