for count in range(5,100000):
    if count % 5 ==0:
        print count
        
        